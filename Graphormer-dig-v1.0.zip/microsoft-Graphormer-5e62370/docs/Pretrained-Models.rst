Pretrained Models
==================

Graphormer provides a series of pre-trained model to help users leverage the power of the model quickly and smoothly. Contributing your pre-trained model by creating a pull request.  

- :ref:`Quick-Start`: as a exmple using pre-trained models.

Pre-trained models from specific papers:

- `Do Transformers Really Perform Badly for Graph Representation? <https://proceedings.neurips.cc/paper/2021/hash/f1c1592588411002af340cbaedd6fc33-Abstract.html>`__
